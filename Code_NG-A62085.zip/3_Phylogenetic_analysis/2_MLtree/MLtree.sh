FastTree -nt tree.phylip > MLtree
